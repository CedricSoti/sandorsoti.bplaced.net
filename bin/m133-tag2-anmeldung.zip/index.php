<?php
header( 'Location: /m133-tag2-anmeldung/templatehtml.html' ) ;
?>